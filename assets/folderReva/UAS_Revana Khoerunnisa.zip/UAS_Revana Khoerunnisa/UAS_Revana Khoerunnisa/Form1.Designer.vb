﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Kwitansi = New System.Windows.Forms.TextBox()
        Me.Harga = New System.Windows.Forms.TextBox()
        Me.Jumlah = New System.Windows.Forms.TextBox()
        Me.Total = New System.Windows.Forms.TextBox()
        Me.Barang = New System.Windows.Forms.ComboBox()
        Me.Baru = New System.Windows.Forms.Button()
        Me.Simpan = New System.Windows.Forms.Button()
        Me.Hapus = New System.Windows.Forms.Button()
        Me.Tutup = New System.Windows.Forms.Button()
        Me.DGVTransaksi = New System.Windows.Forms.DataGridView()
        CType(Me.DGVTransaksi, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(41, 23)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(67, 20)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "Kwitansi"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(41, 77)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(61, 20)
        Me.Label2.TabIndex = 1
        Me.Label2.Text = "Barang"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(41, 130)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(53, 20)
        Me.Label3.TabIndex = 2
        Me.Label3.Text = "Harga"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(410, 23)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(60, 20)
        Me.Label4.TabIndex = 3
        Me.Label4.Text = "Jumlah"
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(410, 77)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(44, 20)
        Me.Label5.TabIndex = 4
        Me.Label5.Text = "Total"
        '
        'Kwitansi
        '
        Me.Kwitansi.Location = New System.Drawing.Point(161, 17)
        Me.Kwitansi.Name = "Kwitansi"
        Me.Kwitansi.Size = New System.Drawing.Size(100, 26)
        Me.Kwitansi.TabIndex = 5
        '
        'Harga
        '
        Me.Harga.Location = New System.Drawing.Point(161, 124)
        Me.Harga.Name = "Harga"
        Me.Harga.Size = New System.Drawing.Size(100, 26)
        Me.Harga.TabIndex = 6
        '
        'Jumlah
        '
        Me.Jumlah.Location = New System.Drawing.Point(543, 17)
        Me.Jumlah.Name = "Jumlah"
        Me.Jumlah.Size = New System.Drawing.Size(100, 26)
        Me.Jumlah.TabIndex = 7
        '
        'Total
        '
        Me.Total.Location = New System.Drawing.Point(543, 74)
        Me.Total.Name = "Total"
        Me.Total.Size = New System.Drawing.Size(100, 26)
        Me.Total.TabIndex = 8
        '
        'Barang
        '
        Me.Barang.FormattingEnabled = True
        Me.Barang.Location = New System.Drawing.Point(161, 69)
        Me.Barang.Name = "Barang"
        Me.Barang.Size = New System.Drawing.Size(177, 28)
        Me.Barang.TabIndex = 9
        '
        'Baru
        '
        Me.Baru.Location = New System.Drawing.Point(51, 179)
        Me.Baru.Name = "Baru"
        Me.Baru.Size = New System.Drawing.Size(75, 23)
        Me.Baru.TabIndex = 10
        Me.Baru.Text = "Baru"
        Me.Baru.UseVisualStyleBackColor = True
        '
        'Simpan
        '
        Me.Simpan.Location = New System.Drawing.Point(172, 179)
        Me.Simpan.Name = "Simpan"
        Me.Simpan.Size = New System.Drawing.Size(75, 23)
        Me.Simpan.TabIndex = 11
        Me.Simpan.Text = "Simpan"
        Me.Simpan.UseVisualStyleBackColor = True
        '
        'Hapus
        '
        Me.Hapus.Location = New System.Drawing.Point(276, 179)
        Me.Hapus.Name = "Hapus"
        Me.Hapus.Size = New System.Drawing.Size(75, 23)
        Me.Hapus.TabIndex = 12
        Me.Hapus.Text = "Hapus"
        Me.Hapus.UseVisualStyleBackColor = True
        '
        'Tutup
        '
        Me.Tutup.Location = New System.Drawing.Point(616, 179)
        Me.Tutup.Name = "Tutup"
        Me.Tutup.Size = New System.Drawing.Size(75, 23)
        Me.Tutup.TabIndex = 13
        Me.Tutup.Text = "Tutup"
        Me.Tutup.UseVisualStyleBackColor = True
        '
        'DGVTransaksi
        '
        Me.DGVTransaksi.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.DGVTransaksi.Location = New System.Drawing.Point(33, 208)
        Me.DGVTransaksi.Name = "DGVTransaksi"
        Me.DGVTransaksi.RowTemplate.Height = 28
        Me.DGVTransaksi.Size = New System.Drawing.Size(658, 150)
        Me.DGVTransaksi.TabIndex = 14
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(9.0!, 20.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(828, 376)
        Me.Controls.Add(Me.DGVTransaksi)
        Me.Controls.Add(Me.Tutup)
        Me.Controls.Add(Me.Hapus)
        Me.Controls.Add(Me.Simpan)
        Me.Controls.Add(Me.Baru)
        Me.Controls.Add(Me.Barang)
        Me.Controls.Add(Me.Total)
        Me.Controls.Add(Me.Jumlah)
        Me.Controls.Add(Me.Harga)
        Me.Controls.Add(Me.Kwitansi)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Label1)
        Me.Name = "Form1"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Form Transaksi"
        CType(Me.DGVTransaksi, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents Kwitansi As System.Windows.Forms.TextBox
    Friend WithEvents Harga As System.Windows.Forms.TextBox
    Friend WithEvents Jumlah As System.Windows.Forms.TextBox
    Friend WithEvents Total As System.Windows.Forms.TextBox
    Friend WithEvents Barang As System.Windows.Forms.ComboBox
    Friend WithEvents Baru As System.Windows.Forms.Button
    Friend WithEvents Simpan As System.Windows.Forms.Button
    Friend WithEvents Hapus As System.Windows.Forms.Button
    Friend WithEvents Tutup As System.Windows.Forms.Button
    Friend WithEvents DGVTransaksi As System.Windows.Forms.DataGridView

End Class
