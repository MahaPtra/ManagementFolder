﻿Public Class Form1
    Public koneksi, sql As String
    Public conn As OleDb.OleDbConnection
    Public cmd As OleDb.OleDbCommand
    Public dtadapter As OleDb.OleDbDataAdapter
    Public tTransaksi As New DataTable

    Sub bersih()
        Kwitansi.Text = ""
        Barang.Text = ""
        Harga.Text = ""
        Jumlah.Text = ""
        Total.Text = ""
    End Sub
    Sub kon_db()
        koneksi = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source=D:\Revana Khoerunnisa\DBTransaksi.accdb"
        conn = New OleDb.OleDbConnection(koneksi)
    End Sub

    Sub save()
        Dim a, b, c, d, e As String
        a = Kwitansi.Text
        b = Barang.Text
        c = Harga.Text
        d = Jumlah.Text
        e = Total.Text

        sql = "INSERT INTO Transaksi VALUES('" & a & "','" & b & "','" & c & "','" & d & "','" & e & "')"
        conn.Open()
        cmd = New OleDb.OleDbCommand(sql, conn)
        cmd.ExecuteNonQuery()
        conn.Close()
    End Sub

    Sub delete()
        sql = "delete from Transaksi where Kwitansi ='" & Kwitansi.Text & "'"
        cmd = New OleDb.OleDbCommand(sql, conn)
        conn.Open()
        cmd.ExecuteNonQuery()
        conn.Close()
    End Sub

    Sub data()
        sql = "select * from Transaksi"
        dtadapter = New OleDb.OleDbDataAdapter(sql, conn)
        tTransaksi.Clear()
        conn.Open()
        dtadapter.Fill(tTransaksi)
        DGVTransaksi.DataSource = tTransaksi
        conn.Close()
    End Sub

    Private Sub Form1_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        kon_db()
        data()
        Barang.Items.Add("Hidrokortison")
        Barang.Items.Add("Metilprednisolon")
        Barang.Items.Add("Nifedipin")
    End Sub

    Private Sub Barang_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Barang.SelectedIndexChanged
        Select Case Barang.SelectedItem
            Case "Hidrokortison"
                Harga.Text = Format(4900, "###,##0")
            Case "Metilprednisolon"
                Harga.Text = Format(16000, "###,##0")
            Case "Nifedipin"
                Harga.Text = Format(19500, "###,##0")
        End Select
        Jumlah.Focus()
    End Sub

    Private Sub Baru_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Baru.Click
        bersih()
    End Sub

    Private Sub Simpan_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Simpan.Click
        save()
        bersih()
        MsgBox("Data Tersimpan")
        data()
    End Sub

    Private Sub Hapus_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Hapus.Click
        delete()
        data()
        bersih()
        MsgBox("data terhapus")
    End Sub

    Private Sub Tutup_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Tutup.Click
        End
    End Sub

    Private Sub DGVTransaksi_CellClick(ByVal sender As Object, ByVal e As System.Windows.Forms.DataGridViewCellEventArgs) Handles DGVTransaksi.CellClick
        Dim a As Integer
        With DGVTransaksi
            a = .CurrentRow.Index
            Kwitansi.Text = .Item(0, a).Value
            Barang.Text = .Item(1, a).Value
            Harga.Text = .Item(2, a).Value
            Jumlah.Text = .Item(3, a).Value
            Total.Text = .Item(4, a).Value
        End With
    End Sub

    Private Sub Jumlah_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles Jumlah.KeyPress
        If Not ((e.KeyChar >= "0" And e.KeyChar <= "9") Or e.KeyChar = vbBack) Then e.Handled = True
        If Asc(e.KeyChar) = Keys.Enter Then
            Simpan.Focus()
        End If
    End Sub

    Private Sub Jumlah_LostFocus(ByVal sender As Object, ByVal e As System.EventArgs) Handles Jumlah.LostFocus
        Total.Text = Format(Harga.Text * Jumlah.Text, "###,##0")
    End Sub

End Class
