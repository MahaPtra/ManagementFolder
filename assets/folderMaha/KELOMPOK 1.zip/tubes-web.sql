-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Waktu pembuatan: 10 Des 2025 pada 04.33
-- Versi server: 10.4.32-MariaDB
-- Versi PHP: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `tubes-web`
--

-- --------------------------------------------------------

--
-- Struktur dari tabel `1a1`
--

CREATE TABLE `1a1` (
  `id` int(11) UNSIGNED NOT NULL,
  `unit_kerja` varchar(255) NOT NULL,
  `nama_ketua` varchar(255) NOT NULL,
  `periode_jabatan` varchar(255) NOT NULL,
  `pendidikan_terakhir` varchar(255) NOT NULL,
  `jabatan_fungsional` varchar(255) NOT NULL,
  `tupoksi` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

-- --------------------------------------------------------

--
-- Struktur dari tabel `1a2`
--

CREATE TABLE `1a2` (
  `id` int(11) UNSIGNED NOT NULL,
  `sumber_pendanaan` varchar(255) NOT NULL,
  `ts_2` varchar(255) NOT NULL,
  `ts_1` varchar(255) NOT NULL,
  `ts` varchar(255) NOT NULL,
  `link_bukti` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

-- --------------------------------------------------------

--
-- Struktur dari tabel `1a3`
--

CREATE TABLE `1a3` (
  `id` int(11) UNSIGNED NOT NULL,
  `sumber_pendanaan` varchar(255) NOT NULL,
  `ts_2` varchar(255) NOT NULL,
  `ts_1` varchar(255) NOT NULL,
  `ts` varchar(255) NOT NULL,
  `link_bukti` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

-- --------------------------------------------------------

--
-- Struktur dari tabel `1a4`
--

CREATE TABLE `1a4` (
  `id` int(11) UNSIGNED NOT NULL,
  `nama_dtpr` varchar(255) NOT NULL,
  `sks_ps_sendiri` varchar(255) NOT NULL,
  `sks_ps_lain_pt_sendiri` varchar(255) NOT NULL,
  `sks_ps_sendiri_penelitian` varchar(255) NOT NULL,
  `sks_ps_sendiri_pengabdian` varchar(255) NOT NULL,
  `sks_ps_sendiri_manajemen` varchar(255) NOT NULL,
  `sks_ps_lain_pt_sendiri_manajemen` varchar(255) NOT NULL,
  `total_sks` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

--
-- Dumping data untuk tabel `1a4`
--

INSERT INTO `1a4` (`id`, `nama_dtpr`, `sks_ps_sendiri`, `sks_ps_lain_pt_sendiri`, `sks_ps_sendiri_penelitian`, `sks_ps_sendiri_pengabdian`, `sks_ps_sendiri_manajemen`, `sks_ps_lain_pt_sendiri_manajemen`, `total_sks`) VALUES
(1, 'TEST', '24', '12', '12', '12', '12', '12', '82'),
(2, 'TEST', '12', '12', '12', '12', '12', '12', '72');

-- --------------------------------------------------------

--
-- Struktur dari tabel `1a5`
--

CREATE TABLE `1a5` (
  `id` int(11) UNSIGNED NOT NULL,
  `jenis_tenaga_kependidikan` varchar(255) NOT NULL,
  `s3` varchar(255) NOT NULL,
  `s2` varchar(255) NOT NULL,
  `s1` varchar(255) NOT NULL,
  `d4` varchar(255) NOT NULL,
  `d3` varchar(255) NOT NULL,
  `d2` varchar(255) NOT NULL,
  `d1` varchar(255) NOT NULL,
  `sma_smk` varchar(255) NOT NULL,
  `unit_kerja` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

--
-- Dumping data untuk tabel `1a5`
--

INSERT INTO `1a5` (`id`, `jenis_tenaga_kependidikan`, `s3`, `s2`, `s1`, `d4`, `d3`, `d2`, `d1`, `sma_smk`, `unit_kerja`) VALUES
(1, 'PDI', '3', '2', '5', '3', '8', '2', '1', '5', 'test');

-- --------------------------------------------------------

--
-- Struktur dari tabel `2d`
--

CREATE TABLE `2d` (
  `Sumber_Rekognisi` varchar(100) DEFAULT NULL,
  `Jenis_Pengakuan_Lulusan` varchar(100) DEFAULT NULL,
  `Tahun_Akademik` year(4) DEFAULT NULL,
  `Link_Bukti` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data untuk tabel `2d`
--

INSERT INTO `2d` (`Sumber_Rekognisi`, `Jenis_Pengakuan_Lulusan`, `Tahun_Akademik`, `Link_Bukti`) VALUES
('Masyarakat', 'Penghargaan Lulusan Inspiratif dari Komunitas Sosial', '2022', 'https://example.com/bukti1'),
('Dunia Usaha', 'Rekruitmen Langsung oleh Startup Nasional', '2023', 'https://example.com/bukti2'),
('Dunia Industri', 'Sertifikasi Keahlian Industri Otomotif', '2021', 'https://example.com/bukti3'),
('Dunia Kerja', 'Diterima Bekerja di BUMN tanpa Tes Tambahan', '2022', 'https://example.com/bukti4');

-- --------------------------------------------------------

--
-- Struktur dari tabel `3a1`
--

CREATE TABLE `3a1` (
  `Nama_Prasarana` varchar(255) DEFAULT NULL,
  `Daya_tampung` int(11) DEFAULT NULL,
  `Luas_ruang` decimal(10,2) DEFAULT NULL,
  `Kepemilikan` varchar(255) DEFAULT NULL,
  `Lisensi` varchar(255) DEFAULT NULL,
  `Perangkat` varchar(255) DEFAULT NULL,
  `Link_Bukti` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data untuk tabel `3a1`
--

INSERT INTO `3a1` (`Nama_Prasarana`, `Daya_tampung`, `Luas_ruang`, `Kepemilikan`, `Lisensi`, `Perangkat`, `Link_Bukti`) VALUES
('Laboratorium Komputer', 30, 60.50, 'M', 'L', 'PC, Laptop, Router, Software Office, Antivirus', 'https://example.com/bukti_lab_komputer'),
('Laboratorium Bahasa', 25, 45.75, 'W', 'T', 'Headset, Software Pembelajaran Bahasa, Proyektor', 'https://example.com/bukti_lab_bahasa'),
('Laboratorium Elektronika', 20, 50.00, 'M', 'P', 'Multimeter, Oscilloscope, Komponen Elektronik, Software Simulasi', 'https://example.com/bukti_lab_elektronika'),
('Laboratorium Jaringan', 35, 70.00, 'M', 'L', 'Switch, Router, Kabel Jaringan, Software Monitoring', 'https://example.com/bukti_lab_jaringan'),
('Laboratorium Kimia', 15, 40.25, 'W', 'L', 'Peralatan Kimia, Alat Pelindung Diri, Software Analisis', 'https://example.com/bukti_lab_kimia');

-- --------------------------------------------------------

--
-- Struktur dari tabel `3a2`
--

CREATE TABLE `3a2` (
  `Nama_DTPR` varchar(255) DEFAULT NULL,
  `Judul_Penelitian` text DEFAULT NULL,
  `Jumlah_Mahasiswa_Terlibat` int(11) DEFAULT NULL,
  `Jenis_Hibah_Penelitian` varchar(100) DEFAULT NULL,
  `Sumber` enum('L','N','I') DEFAULT NULL,
  `Durasi` varchar(50) DEFAULT NULL,
  `TS_2` decimal(15,2) DEFAULT NULL,
  `TS_1` decimal(15,2) DEFAULT NULL,
  `TS` decimal(15,2) DEFAULT NULL,
  `Link_Bukti` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data untuk tabel `3a2`
--

INSERT INTO `3a2` (`Nama_DTPR`, `Judul_Penelitian`, `Jumlah_Mahasiswa_Terlibat`, `Jenis_Hibah_Penelitian`, `Sumber`, `Durasi`, `TS_2`, `TS_1`, `TS`, `Link_Bukti`) VALUES
('Dr. Andi Saputra', 'Pengembangan Metode Pembelajaran Interaktif', 5, 'Hibah Dasar', 'L', '1 Tahun', 50000000.00, 60000000.00, 70000000.00, 'https://example.com/bukti_penelitian1'),
('Prof. Sari Dewi', 'Studi Pengaruh Teknologi Nano pada Kesehatan', 3, 'Hibah Terapan', 'N', '2 Tahun', 150000000.00, 140000000.00, 130000000.00, 'https://example.com/bukti_penelitian2'),
('Dr. Budi Santoso', 'Analisis Big Data untuk Prediksi Cuaca', 4, 'Hibah Kompetitif', 'I', '18 Bulan', 200000000.00, 210000000.00, 220000000.00, 'https://example.com/bukti_penelitian3'),
('Dr. Rina Puspita', 'Inovasi Energi Terbarukan Berbasis Biomassa', 6, 'Hibah Dasar', 'L', '1 Tahun', 45000000.00, 47000000.00, 49000000.00, 'https://example.com/bukti_penelitian4'),
('Prof. Agus Wijaya', 'Pengembangan Sistem Keamanan Siber', 2, 'Hibah Kompetitif', 'N', '2 Tahun', 120000000.00, 125000000.00, 130000000.00, 'https://example.com/bukti_penelitian5');

-- --------------------------------------------------------

--
-- Struktur dari tabel `3a3`
--

CREATE TABLE `3a3` (
  `Jenis_Pengembangan_DTPR` varchar(255) DEFAULT NULL,
  `Nama_DTPR` varchar(255) DEFAULT NULL,
  `Jumlah_Dosen_TS_2` int(11) DEFAULT NULL,
  `Jumlah_Dosen_TS_1` int(11) DEFAULT NULL,
  `Jumlah_Dosen_TS` int(11) DEFAULT NULL,
  `Link_Bukti` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data untuk tabel `3a3`
--

INSERT INTO `3a3` (`Jenis_Pengembangan_DTPR`, `Nama_DTPR`, `Jumlah_Dosen_TS_2`, `Jumlah_Dosen_TS_1`, `Jumlah_Dosen_TS`, `Link_Bukti`) VALUES
('Pelatihan Pendidikan', 'Dr. Andi Saputra', 3, 4, 5, 'https://example.com/bukti_pengembangan1'),
('Seminar Nasional', 'Prof. Sari Dewi', 2, 2, 3, 'https://example.com/bukti_pengembangan2'),
('Tugas Belajar', 'Dr. Budi Santoso', 0, 1, 1, 'https://example.com/bukti_pengembangan3'),
('Workshop Teknologi', 'Dr. Rina Puspita', 4, 5, 6, 'https://example.com/bukti_pengembangan4'),
('Pelatihan Kepemimpinan', 'Prof. Agus Wijaya', 1, 1, 2, 'https://example.com/bukti_pengembangan5');

-- --------------------------------------------------------

--
-- Struktur dari tabel `4c3`
--

CREATE TABLE `4c3` (
  `no` int(11) NOT NULL,
  `judul` varchar(200) DEFAULT NULL,
  `judul_hki` varchar(200) DEFAULT NULL,
  `nama_dtpr` varchar(100) DEFAULT NULL,
  `tahun_ts2` varchar(5) DEFAULT '',
  `tahun_ts1` varchar(5) DEFAULT '',
  `tahun_ts` varchar(5) DEFAULT '',
  `link_bukti` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data untuk tabel `4c3`
--

INSERT INTO `4c3` (`no`, `judul`, `judul_hki`, `nama_dtpr`, `tahun_ts2`, `tahun_ts1`, `tahun_ts`, `link_bukti`) VALUES
(1, 'XIV', 'CED', 'Prof. Membrane', '?', '', '', 'https://kuliahonline.widyatama.ac.id/mod/assign/view.php?id=131153');

-- --------------------------------------------------------

--
-- Struktur dari tabel `5_1`
--

CREATE TABLE `5_1` (
  `no` int(11) NOT NULL,
  `jenis_tata_kelola` varchar(100) DEFAULT NULL,
  `nama_sistem` varchar(150) DEFAULT NULL,
  `akses` varchar(100) DEFAULT NULL,
  `unit_kerja_pengelola` varchar(150) DEFAULT NULL,
  `link_bukti` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data untuk tabel `5_1`
--

INSERT INTO `5_1` (`no`, `jenis_tata_kelola`, `nama_sistem`, `akses`, `unit_kerja_pengelola`, `link_bukti`) VALUES
(1, 'Pendidikan', 'Sistem Informasi Akademik Mahasiswa (SIAKAD)', 'https://utama.widyatama.ac.id/auth', 'Bagian Akademik', 'https://kuliahonline.widyatama.ac.id/mod/assign/view.php?id=131153'),
(2, 'Keuangan', NULL, NULL, NULL, NULL),
(3, 'SDM', NULL, NULL, NULL, NULL),
(4, 'Sarana Prasarana', NULL, NULL, NULL, NULL),
(5, 'Sistem Penjaminan Mutu', NULL, NULL, NULL, NULL);

-- --------------------------------------------------------

--
-- Struktur dari tabel `5_2`
--

CREATE TABLE `5_2` (
  `id` int(11) NOT NULL,
  `nama_prasarana` varchar(150) DEFAULT NULL,
  `daya_tampung` int(11) DEFAULT NULL,
  `luas_ruang` decimal(8,2) DEFAULT NULL,
  `status_kepemilikan` enum('Milik Sendiri','Sewa') DEFAULT NULL,
  `status_lisensi` enum('Berlisensi','Tidak Berlisensi','Public Domain') DEFAULT NULL,
  `perangkat` varchar(150) DEFAULT NULL,
  `link_bukti` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data untuk tabel `5_2`
--

INSERT INTO `5_2` (`id`, `nama_prasarana`, `daya_tampung`, `luas_ruang`, `status_kepemilikan`, `status_lisensi`, `perangkat`, `link_bukti`) VALUES
(1, 'Ruang Kelas 409', 30, 60.00, 'Milik Sendiri', 'Berlisensi', 'Proyektor, AC', 'https://bit.ly...');

-- --------------------------------------------------------

--
-- Struktur dari tabel `data_mahasiswa`
--

CREATE TABLE `data_mahasiswa` (
  `ts_tahun` varchar(5) NOT NULL,
  `daya_tampung` int(11) DEFAULT 0,
  `calon_pendaftar_afirmasi` int(11) DEFAULT 0,
  `calon_pendaftar_khusus` int(11) DEFAULT 0,
  `calon_pendaftar_kebutuhan` int(11) DEFAULT 0,
  `maba_reguler_diterima` int(11) DEFAULT 0,
  `maba_reguler_afirmasi` int(11) DEFAULT 0,
  `maba_reguler_kebutuhan_khusus` int(11) DEFAULT 0,
  `maba_rpl_diterima` int(11) DEFAULT 0,
  `maba_rpl_afirmasi` int(11) DEFAULT 0,
  `maba_rpl_kebutuhan_khusus` int(11) DEFAULT 0,
  `aktif_reguler_diterima` int(11) DEFAULT 0,
  `aktif_reguler_afirmasi` int(11) DEFAULT 0,
  `aktif_reguler_kebutuhan_khusus` int(11) DEFAULT 0,
  `aktif_rpl_diterima` int(11) DEFAULT 0,
  `aktif_rpl_afirmasi` int(11) DEFAULT 0,
  `aktif_rpl_kebutuhan_khusus` int(11) DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data untuk tabel `data_mahasiswa`
--

INSERT INTO `data_mahasiswa` (`ts_tahun`, `daya_tampung`, `calon_pendaftar_afirmasi`, `calon_pendaftar_khusus`, `calon_pendaftar_kebutuhan`, `maba_reguler_diterima`, `maba_reguler_afirmasi`, `maba_reguler_kebutuhan_khusus`, `maba_rpl_diterima`, `maba_rpl_afirmasi`, `maba_rpl_kebutuhan_khusus`, `aktif_reguler_diterima`, `aktif_reguler_afirmasi`, `aktif_reguler_kebutuhan_khusus`, `aktif_rpl_diterima`, `aktif_rpl_afirmasi`, `aktif_rpl_kebutuhan_khusus`) VALUES
('TS', 100, 50, 0, 0, 45, 0, 0, 0, 0, 0, 150, 0, 0, 0, 0, 0),
('TS-1', 90, 40, 5, 1, 40, 4, 0, 20, 0, 0, 280, 2, 0, 57, 0, 0),
('TS-2', 90, 40, 3, 2, 85, 3, 2, 15, 0, 0, 240, 1, 1, 37, 0, 0),
('TS-3', 80, 35, 2, 0, 80, 1, 0, 12, 1, 0, 155, 0, 0, 22, 0, 0),
('TS-4', 80, 30, 5, 1, 75, 2, 1, 10, 0, 0, 75, 0, 0, 10, 0, 0);

-- --------------------------------------------------------

--
-- Struktur dari tabel `fleksibilitaspembelajaran`
--

CREATE TABLE `fleksibilitaspembelajaran` (
  `TahunAkademik` varchar(10) DEFAULT NULL,
  `JenisPembelajaran` varchar(50) DEFAULT NULL,
  `TS_2` int(11) DEFAULT NULL,
  `TS_1` int(11) DEFAULT NULL,
  `TS` int(11) DEFAULT NULL,
  `LinkBukti` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data untuk tabel `fleksibilitaspembelajaran`
--

INSERT INTO `fleksibilitaspembelajaran` (`TahunAkademik`, `JenisPembelajaran`, `TS_2`, `TS_1`, `TS`, `LinkBukti`) VALUES
('TS-2', 'Jumlah Mahasiswa Aktif', 100, 120, 130, NULL),
('TS-2', 'Micro-credential', 10, 15, 20, NULL),
('TS-2', 'RPL tipe A-2', 5, 10, 8, NULL),
('TS-2', 'Pembelajaran di PS lain', 8, 7, 10, NULL),
('TS-2', 'Pembelajaran di PT lain', 6, 8, 9, NULL),
('TS-2', 'CBL/PBL', 12, 15, 18, NULL);

-- --------------------------------------------------------

--
-- Struktur dari tabel `isi_pembelajaran`
--

CREATE TABLE `isi_pembelajaran` (
  `no` int(11) NOT NULL,
  `mata_kuliah` varchar(100) NOT NULL,
  `sks` tinyint(4) NOT NULL,
  `semester` tinyint(4) NOT NULL,
  `pl1` tinyint(4) DEFAULT 0,
  `pl2` tinyint(4) DEFAULT 0,
  `pl3` tinyint(4) DEFAULT 0,
  `pl4` tinyint(4) DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data untuk tabel `isi_pembelajaran`
--

INSERT INTO `isi_pembelajaran` (`no`, `mata_kuliah`, `sks`, `semester`, `pl1`, `pl2`, `pl3`, `pl4`) VALUES
(1, 'Pengantar Informatika', 3, 1, 1, 0, 0, 0),
(2, 'Algoritma dan Pemrograman', 4, 2, 1, 1, 0, 0),
(3, 'Struktur Data', 3, 3, 0, 1, 1, 0),
(4, 'Basis Data', 3, 4, 0, 1, 1, 1),
(5, 'Sistem Operasi', 3, 4, 0, 0, 1, 1);

-- --------------------------------------------------------

--
-- Struktur dari tabel `kepuasan_pengguna_lulusan`
--

CREATE TABLE `kepuasan_pengguna_lulusan` (
  `id` int(11) NOT NULL,
  `jenis_kemampuan` varchar(100) DEFAULT NULL,
  `sangat_baik` int(11) DEFAULT 0,
  `baik` int(11) DEFAULT 0,
  `cukup` int(11) DEFAULT 0,
  `kurang` int(11) DEFAULT 0,
  `rencana_tindak` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data untuk tabel `kepuasan_pengguna_lulusan`
--

INSERT INTO `kepuasan_pengguna_lulusan` (`id`, `jenis_kemampuan`, `sangat_baik`, `baik`, `cukup`, `kurang`, `rencana_tindak`) VALUES
(1, 'Kerjasama Tim', 20, 30, 10, 5, 'Pelatihan teamwork'),
(2, 'Keahlian di Bidang Prodi', 15, 35, 15, 5, 'Upgrade kurikulum'),
(3, 'Kemampuan Berbahasa Asing (Inggris)', 10, 25, 20, 10, 'Kursus bahasa'),
(4, 'Kemampuan Berkomunikasi', 25, 20, 15, 5, 'Workshop komunikasi'),
(5, 'Pengembangan Diri', 30, 25, 10, 5, 'Seminar motivasi'),
(6, 'Kepemimpinan', 15, 30, 20, 5, 'Pelatihan kepemimpinan'),
(7, 'Etos Kerja', 40, 25, 10, 5, 'Program motivasi');

-- --------------------------------------------------------

--
-- Struktur dari tabel `keragaman_asal_mahasiswa`
--

CREATE TABLE `keragaman_asal_mahasiswa` (
  `asal_mahasiswa` varchar(100) NOT NULL,
  `ts_2` int(11) DEFAULT 0,
  `ts_1` int(11) DEFAULT 0,
  `ts` int(11) DEFAULT 0,
  `link_bukti` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data untuk tabel `keragaman_asal_mahasiswa`
--

INSERT INTO `keragaman_asal_mahasiswa` (`asal_mahasiswa`, `ts_2`, `ts_1`, `ts`, `link_bukti`) VALUES
('Afirmasi', 10, 12, 15, 'http://link.bukti/afirmasi'),
('Berkebutuhan Khusus', 0, 0, 0, NULL),
('Kota/Kab sama dengan PS', 150, 160, 170, 'http://link.bukti/kabupaten'),
('Kota/Kabupaten Lain', 0, 0, 0, NULL),
('Negara Lain', 0, 0, 0, NULL);

-- --------------------------------------------------------

--
-- Struktur dari tabel `kerjasama_penelitian`
--

CREATE TABLE `kerjasama_penelitian` (
  `No` int(11) DEFAULT NULL,
  `Judul_Kerjasama` text DEFAULT NULL,
  `Mitra_Kerjasama` varchar(255) DEFAULT NULL,
  `Sumber_LNI` enum('L','N','I') DEFAULT NULL,
  `Durasi_Tahun` tinyint(4) DEFAULT NULL,
  `Pendanaan_TS2` bigint(20) DEFAULT NULL,
  `Pendanaan_TS1` bigint(20) DEFAULT NULL,
  `Pendanaan_TS` bigint(20) DEFAULT NULL,
  `Link_Bukti` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data untuk tabel `kerjasama_penelitian`
--

INSERT INTO `kerjasama_penelitian` (`No`, `Judul_Kerjasama`, `Mitra_Kerjasama`, `Sumber_LNI`, `Durasi_Tahun`, `Pendanaan_TS2`, `Pendanaan_TS1`, `Pendanaan_TS`, `Link_Bukti`) VALUES
(1, 'Contoh Judul 1', 'Contoh Mitra 1', 'N', 3, 0, 10000000, 11000000, 'http://contoh1.com');

-- --------------------------------------------------------

--
-- Struktur dari tabel `kesesuaianvisimisi`
--

CREATE TABLE `kesesuaianvisimisi` (
  `VismisID` int(11) NOT NULL,
  `VistPT` varchar(255) DEFAULT NULL,
  `VisiUPPS` varchar(255) DEFAULT NULL,
  `VisiKeilmuanPS` varchar(255) DEFAULT NULL,
  `MisiPT` varchar(255) DEFAULT NULL,
  `MisiUPPS` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data untuk tabel `kesesuaianvisimisi`
--

INSERT INTO `kesesuaianvisimisi` (`VismisID`, `VistPT`, `VisiUPPS`, `VisiKeilmuanPS`, `MisiPT`, `MisiUPPS`) VALUES
(1, 'Menjadi PT yang mantap banget', 'Mencari Peluang Di dalam kesulitan', 'Cari ilmu sampe negri China', 'Menjalankan Program Perusahaan', 'Menerapkan sistem kerja skuyliving');

-- --------------------------------------------------------

--
-- Struktur dari tabel `kesesuaian_bidang_kerja_lulusan`
--

CREATE TABLE `kesesuaian_bidang_kerja_lulusan` (
  `id` int(11) NOT NULL,
  `tahun_lulus` varchar(10) DEFAULT NULL,
  `jumlah_lulusan` int(11) DEFAULT NULL,
  `jumlah_lulusan_terlacak` int(11) DEFAULT NULL,
  `profesi_kerja_bidang_infokom` int(11) DEFAULT NULL,
  `profesi_kerja_bidang_non_infokom` int(11) DEFAULT NULL,
  `lingkup_multinasional` int(11) DEFAULT NULL,
  `lingkup_nasional` int(11) DEFAULT NULL,
  `lingkup_wirausaha` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data untuk tabel `kesesuaian_bidang_kerja_lulusan`
--

INSERT INTO `kesesuaian_bidang_kerja_lulusan` (`id`, `tahun_lulus`, `jumlah_lulusan`, `jumlah_lulusan_terlacak`, `profesi_kerja_bidang_infokom`, `profesi_kerja_bidang_non_infokom`, `lingkup_multinasional`, `lingkup_nasional`, `lingkup_wirausaha`) VALUES
(1, 'TS-2', 100, 90, 60, 30, 20, 60, 10),
(2, 'TS-1', 120, 110, 70, 40, 25, 70, 15),
(3, 'TS', 130, 115, 80, 35, 30, 65, 20);

-- --------------------------------------------------------

--
-- Struktur dari tabel `kondisi_mahasiswa`
--

CREATE TABLE `kondisi_mahasiswa` (
  `id` int(11) NOT NULL,
  `sumber_pendanaan` varchar(100) DEFAULT NULL,
  `ts_2` int(11) DEFAULT NULL,
  `ts_1` int(11) DEFAULT NULL,
  `ts` int(11) DEFAULT NULL,
  `jumlah` int(11) DEFAULT NULL,
  `upload_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data untuk tabel `kondisi_mahasiswa`
--

INSERT INTO `kondisi_mahasiswa` (`id`, `sumber_pendanaan`, `ts_2`, `ts_1`, `ts`, `jumlah`, `upload_id`) VALUES
(1, 'Mahasiswa Sendiri', 45, 50, 60, 155, NULL),
(2, 'Beasiswa Pemerintah', 30, 28, 25, 83, NULL),
(3, 'Beasiswa Swasta', 15, 20, 22, 57, NULL),
(4, 'Lainnya', 5, 7, 8, 20, NULL);

-- --------------------------------------------------------

--
-- Struktur dari tabel `kond_jumlah_mahasiswa`
--

CREATE TABLE `kond_jumlah_mahasiswa` (
  `id` int(11) NOT NULL,
  `sumber_pendanaan` varchar(100) NOT NULL,
  `ts_minus_2` int(11) DEFAULT 0,
  `ts_minus_1` int(11) DEFAULT 0,
  `ts` int(11) DEFAULT 0,
  `jumlah` int(11) GENERATED ALWAYS AS (`ts_minus_2` + `ts_minus_1` + `ts`) STORED
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data untuk tabel `kond_jumlah_mahasiswa`
--

INSERT INTO `kond_jumlah_mahasiswa` (`id`, `sumber_pendanaan`, `ts_minus_2`, `ts_minus_1`, `ts`) VALUES
(1, 'Mahasiswa baru', 120, 140, 130),
(2, 'Mahasiswa Aktif pada saat TS', 800, 820, 840),
(3, 'Lulus pada saat TS', 200, 220, 210),
(4, 'Mengundurkan Diri/DO pada saat TS', 5, 3, 4);

-- --------------------------------------------------------

--
-- Struktur dari tabel `kualifikasi_tenaga_kependidikan`
--

CREATE TABLE `kualifikasi_tenaga_kependidikan` (
  `no` int(11) NOT NULL,
  `jenis_tenaga` varchar(100) NOT NULL,
  `s3` int(11) DEFAULT 0,
  `s2` int(11) DEFAULT 0,
  `s1` int(11) DEFAULT 0,
  `d4` int(11) DEFAULT 0,
  `d3` int(11) DEFAULT 0,
  `d2` int(11) DEFAULT 0,
  `d1` int(11) DEFAULT 0,
  `sma_smk` int(11) DEFAULT 0,
  `unit_kerja` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data untuk tabel `kualifikasi_tenaga_kependidikan`
--

INSERT INTO `kualifikasi_tenaga_kependidikan` (`no`, `jenis_tenaga`, `s3`, `s2`, `s1`, `d4`, `d3`, `d2`, `d1`, `sma_smk`, `unit_kerja`) VALUES
(1, 'Pustakawan*)', 1, 2, 5, 1, 3, 0, 1, 1, 'Perpustakaan Pusat'),
(2, 'Laboran/Teknisi', 0, 1, 7, 2, 8, 4, 0, 3, 'Lab Terpadu'),
(3, 'Administrasi', 0, 3, 15, 1, 4, 2, 1, 20, 'Rektorat & Fakultas'),
(4, 'Lainnya', 1, 0, 2, 0, 1, 1, 0, 5, 'Lain-lain');

-- --------------------------------------------------------

--
-- Struktur dari tabel `migrations`
--

CREATE TABLE `migrations` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `version` varchar(255) NOT NULL,
  `class` varchar(255) NOT NULL,
  `group` varchar(255) NOT NULL,
  `namespace` varchar(255) NOT NULL,
  `time` int(11) NOT NULL,
  `batch` int(11) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

--
-- Dumping data untuk tabel `migrations`
--

INSERT INTO `migrations` (`id`, `version`, `class`, `group`, `namespace`, `time`, `batch`) VALUES
(1, '2023-12-02-074046', 'App\\Database\\Migrations\\News', 'default', 'App', 1764129578, 1),
(2, '2023-12-02-074436', 'App\\Database\\Migrations\\AlterNews', 'default', 'App', 1764129578, 1),
(5, '2023-12-15-071547', 'App\\Database\\Migrations\\Users', 'default', 'App', 1764681141, 2),
(6, '2023-12-20-034521', 'App\\Database\\Migrations\\Within', 'default', 'App', 1764681141, 2),
(7, '2025-11-29-152500', 'App\\Database\\Migrations\\AddNewTables', 'default', 'App', 1764681141, 2),
(8, '2025-11-29-153500', 'App\\Database\\Migrations\\DropLegacyTables', 'default', 'App', 1764681142, 2);

-- --------------------------------------------------------

--
-- Struktur dari tabel `pemetaan_cpl`
--

CREATE TABLE `pemetaan_cpl` (
  `id` int(11) NOT NULL,
  `cpl_code` varchar(20) NOT NULL,
  `pl1` tinyint(4) DEFAULT 0,
  `pl2` tinyint(4) DEFAULT 0,
  `pl3` tinyint(4) DEFAULT 0,
  `pl4` tinyint(4) DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data untuk tabel `pemetaan_cpl`
--

INSERT INTO `pemetaan_cpl` (`id`, `cpl_code`, `pl1`, `pl2`, `pl3`, `pl4`) VALUES
(1, 'CPL1', 1, 0, 1, 0),
(2, 'CPL2', 0, 1, 1, 0),
(3, 'CPL3', 0, 0, 1, 1);

-- --------------------------------------------------------

--
-- Struktur dari tabel `penelitian_dtpr`
--

CREATE TABLE `penelitian_dtpr` (
  `id` int(11) NOT NULL,
  `nama_dtpr` varchar(255) NOT NULL,
  `judul_penelitian` text DEFAULT NULL,
  `jml_mahasiswa_terlibat` int(11) DEFAULT NULL,
  `jenis_hibah_penelitian` varchar(100) DEFAULT NULL,
  `sumber` enum('L','N','I') DEFAULT NULL COMMENT 'L: Lokal, N: Nasional, I: Internasional',
  `durasi` varchar(50) DEFAULT NULL,
  `pendanaan_ts_2` decimal(15,2) DEFAULT 0.00,
  `pendanaan_ts_1` decimal(15,2) DEFAULT 0.00,
  `pendanaan_ts` decimal(15,2) DEFAULT 0.00,
  `link_bukti` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data untuk tabel `penelitian_dtpr`
--

INSERT INTO `penelitian_dtpr` (`id`, `nama_dtpr`, `judul_penelitian`, `jml_mahasiswa_terlibat`, `jenis_hibah_penelitian`, `sumber`, `durasi`, `pendanaan_ts_2`, `pendanaan_ts_1`, `pendanaan_ts`, `link_bukti`) VALUES
(1, 'Dr. Budi Santoso', 'Riset AI untuk Deteksi Hama', 5, 'Hibah Internal', 'L', '1 Tahun', 0.00, 0.00, 50.00, 'http://link.com/1'),
(2, 'Prof. Rina Wijaya', 'Pengembangan Material Nano', 3, 'Hibah Dikti', 'N', '2 Tahun', 0.00, 0.00, 150.00, 'http://link.com/2'),
(3, 'Dr. Budi Santoso', 'Riset IoT untuk Pertanian', 4, 'Hibah Internal', 'L', '1 Tahun', 0.00, 0.00, 75.00, 'http://link.com/3');

-- --------------------------------------------------------

--
-- Struktur dari tabel `pengembangan_dtpr`
--

CREATE TABLE `pengembangan_dtpr` (
  `id` int(11) NOT NULL,
  `jenis_pengembangan_dtpr` varchar(255) DEFAULT NULL,
  `nama_dtpr` varchar(255) DEFAULT NULL,
  `jumlah_ts_2` int(11) DEFAULT 0,
  `jumlah_ts_1` int(11) DEFAULT 0,
  `jumlah_ts` int(11) DEFAULT 0,
  `link_bukti` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data untuk tabel `pengembangan_dtpr`
--

INSERT INTO `pengembangan_dtpr` (`id`, `jenis_pengembangan_dtpr`, `nama_dtpr`, `jumlah_ts_2`, `jumlah_ts_1`, `jumlah_ts`, `link_bukti`) VALUES
(1, 'Studi Lanjut S3', 'Dr. Budi Santoso', 1, 0, 0, 'http://link.com/sertifikat-budi'),
(2, 'Seminar Internasional', 'Prof. Rina Wijaya', 1, 1, 2, 'http://link.com/sertifikat-rina'),
(3, 'Pelatihan Kompetensi', 'Ahmad Zulkifli, M.T.', 0, 0, 1, 'http://link.com/sertifikat-ahmad');

-- --------------------------------------------------------

--
-- Struktur dari tabel `perolehanhkipkm`
--

CREATE TABLE `perolehanhkipkm` (
  `hkiID` int(11) NOT NULL,
  `Judul` varchar(255) DEFAULT NULL,
  `JudulHKI` varchar(255) DEFAULT NULL,
  `NamaDTPR` varchar(50) DEFAULT NULL,
  `TS_2` tinyint(1) DEFAULT NULL,
  `TS_1` tinyint(1) DEFAULT NULL,
  `TS` tinyint(1) DEFAULT NULL,
  `LinkBukti` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data untuk tabel `perolehanhkipkm`
--

INSERT INTO `perolehanhkipkm` (`hkiID`, `Judul`, `JudulHKI`, `NamaDTPR`, `TS_2`, `TS_1`, `TS`, `LinkBukti`) VALUES
(1, 'Disertasi Tentang Lorem Ipsum', 'Hak Cipta', 'Dr. Daffa Apta Pratama ST. MT', 1, 0, 1, 'https://example.com/hakcipta'),
(2, 'Pengembangan Sistem Informasi', 'Paten', 'Dr. Andi Prabowo', 1, 1, 0, 'https://example.com/paten'),
(3, 'Penelitian Inovatif di Bidang Teknologi', 'Hak Cipta', 'Prof. Budi Santoso', 0, 0, 1, 'https://example.com/hakcipta');

-- --------------------------------------------------------

--
-- Struktur dari tabel `perolehan_hki`
--

CREATE TABLE `perolehan_hki` (
  `No` int(11) DEFAULT NULL,
  `Judul` text DEFAULT NULL,
  `Judul_HKI` text DEFAULT NULL,
  `Nama_DTPR` varchar(255) DEFAULT NULL,
  `Tahun_Perolehan_TS2` tinyint(1) DEFAULT NULL,
  `Tahun_Perolehan_TS1` tinyint(1) DEFAULT NULL,
  `Tahun_Perolehan_TS` tinyint(1) DEFAULT NULL,
  `Link_Bukti` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data untuk tabel `perolehan_hki`
--

INSERT INTO `perolehan_hki` (`No`, `Judul`, `Judul_HKI`, `Nama_DTPR`, `Tahun_Perolehan_TS2`, `Tahun_Perolehan_TS1`, `Tahun_Perolehan_TS`, `Link_Bukti`) VALUES
(1, 'Contoh Judul 1', 'Contoh Nama 1', 'contoh dptr', 2, 4, 5, 'http://contoh1.com');

-- --------------------------------------------------------

--
-- Struktur dari tabel `peta_pemenuhan_cpl`
--

CREATE TABLE `peta_pemenuhan_cpl` (
  `id` int(11) NOT NULL,
  `cpl_code` varchar(20) NOT NULL,
  `cpmk_code` varchar(30) DEFAULT NULL,
  `semester1` varchar(30) DEFAULT NULL,
  `semester2` varchar(30) DEFAULT NULL,
  `semester3` varchar(30) DEFAULT NULL,
  `semester4` varchar(30) DEFAULT NULL,
  `semester5` varchar(30) DEFAULT NULL,
  `semester6` varchar(30) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data untuk tabel `peta_pemenuhan_cpl`
--

INSERT INTO `peta_pemenuhan_cpl` (`id`, `cpl_code`, `cpmk_code`, `semester1`, `semester2`, `semester3`, `semester4`, `semester5`, `semester6`) VALUES
(1, 'CPL01', 'CPMK01', 'MK01', 'MK02', NULL, NULL, NULL, NULL),
(2, 'CPL02', 'CPMK02', 'MK03', NULL, 'MK05', NULL, NULL, NULL),
(3, 'CPL03', 'CPMK03', NULL, 'MK04', 'MK06', NULL, NULL, NULL);

-- --------------------------------------------------------

--
-- Struktur dari tabel `publikasi_penelitian`
--

CREATE TABLE `publikasi_penelitian` (
  `No` int(11) DEFAULT NULL,
  `Nama_DTPR` varchar(255) DEFAULT NULL,
  `Judul_Publikasi` text DEFAULT NULL,
  `Jenis_Publikasi` enum('IB','I','S1','S2','S3','S4','T') DEFAULT NULL,
  `Tahun_terbit_TS2` tinyint(1) DEFAULT NULL,
  `Tahun_terbit_TS1` tinyint(1) DEFAULT NULL,
  `Tahun_terbit_TS` tinyint(1) DEFAULT NULL,
  `Link_bukti` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data untuk tabel `publikasi_penelitian`
--

INSERT INTO `publikasi_penelitian` (`No`, `Nama_DTPR`, `Judul_Publikasi`, `Jenis_Publikasi`, `Tahun_terbit_TS2`, `Tahun_terbit_TS1`, `Tahun_terbit_TS`, `Link_bukti`) VALUES
(1, 'Contoh Nama 1', 'Contoh Judul 1', 'IB', 1, 1, 1, 'http://contoh1.com');

-- --------------------------------------------------------

--
-- Struktur dari tabel `rata_rata_masa_tunggu`
--

CREATE TABLE `rata_rata_masa_tunggu` (
  `id` int(11) NOT NULL,
  `tahun_lulus` varchar(10) DEFAULT NULL,
  `jumlah_lulusan` int(11) DEFAULT NULL,
  `jumlah_lulusan_terlacak` int(11) DEFAULT NULL,
  `rata_rata_waktu_tunggu_bulan` decimal(5,2) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data untuk tabel `rata_rata_masa_tunggu`
--

INSERT INTO `rata_rata_masa_tunggu` (`id`, `tahun_lulus`, `jumlah_lulusan`, `jumlah_lulusan_terlacak`, `rata_rata_waktu_tunggu_bulan`) VALUES
(1, 'TS-2', 100, 90, 3.50),
(2, 'TS-1', 120, 110, 2.80),
(3, 'TS', 130, 115, 3.10);

-- --------------------------------------------------------

--
-- Struktur dari tabel `rekognisi_lulusan`
--

CREATE TABLE `rekognisi_lulusan` (
  `id` int(11) NOT NULL,
  `kategori` varchar(20) NOT NULL,
  `sumber` varchar(100) NOT NULL,
  `jenis_pengakuan` varchar(255) DEFAULT NULL,
  `ts_2` int(11) DEFAULT 0,
  `ts_1` int(11) DEFAULT 0,
  `ts` int(11) DEFAULT 0,
  `link_bukti` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data untuk tabel `rekognisi_lulusan`
--

INSERT INTO `rekognisi_lulusan` (`id`, `kategori`, `sumber`, `jenis_pengakuan`, `ts_2`, `ts_1`, `ts`, `link_bukti`) VALUES
(1, 'Rekognisi', 'Masyarakat', 'Survey Kepuasan Publik', 10, 12, 15, 'http://link.com/1'),
(2, 'Rekognisi', 'Dunia Usaha', 'Perekrutan Lulusan > 3 bulan', 5, 8, 10, 'http://link.com/2'),
(3, 'Rekognisi', 'Dunia Industri', 'Kemitraan Riset', 3, 2, 5, 'http://link.com/3'),
(4, 'Rekognisi', 'Dunia Kerja', 'Testimoni Pengguna Lulusan', 7, 7, 8, 'http://link.com/4'),
(5, 'Lulusan', 'Jumlah Lulusan', NULL, 80, 90, 100, NULL);

-- --------------------------------------------------------

--
-- Struktur dari tabel `saranadanprasaranapendidikan`
--

CREATE TABLE `saranadanprasaranapendidikan` (
  `prasaranaID` int(11) NOT NULL,
  `NamaPrasarana` varchar(255) DEFAULT NULL,
  `DayaTampung` int(11) DEFAULT NULL,
  `LuasRuang_m2` float DEFAULT NULL,
  `MilikSendiriAtauSewa` tinyint(1) DEFAULT NULL,
  `BerlisensiLatauPublicDomainPatauTidakBerlisensiT` tinyint(1) DEFAULT NULL,
  `Perangkat` varchar(50) DEFAULT NULL,
  `LinkBukti` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data untuk tabel `saranadanprasaranapendidikan`
--

INSERT INTO `saranadanprasaranapendidikan` (`prasaranaID`, `NamaPrasarana`, `DayaTampung`, `LuasRuang_m2`, `MilikSendiriAtauSewa`, `BerlisensiLatauPublicDomainPatauTidakBerlisensiT`, `Perangkat`, `LinkBukti`) VALUES
(1, 'Kolam Renang', 5, 20, 1, 0, 'mikrotik', 'https://google.com'),
(2, 'Lapangan Sepak Bola', 11, 50, 1, 1, 'router', 'https://youtube.com'),
(3, 'Ruang Kelas', 30, 60, 0, 1, 'switch', 'https://facebook.com');

-- --------------------------------------------------------

--
-- Struktur dari tabel `sarana_prasarana_penelitian`
--

CREATE TABLE `sarana_prasarana_penelitian` (
  `id` int(11) NOT NULL,
  `nama_prasarana` varchar(255) NOT NULL,
  `daya_tampung` int(11) DEFAULT NULL,
  `luas_ruang_m2` decimal(10,2) DEFAULT NULL,
  `status_kepemilikan` enum('M','W') DEFAULT NULL COMMENT 'M: Milik sendiri, W: Sewa',
  `status_lisensi` enum('L','P','T') DEFAULT NULL COMMENT 'L: Berlisensi, P: Public Domain, T: Tidak Berlisensi',
  `perangkat` text DEFAULT NULL,
  `keterangan_lain` varchar(255) DEFAULT NULL COMMENT 'Kolom ... (Kolom 7)',
  `link_bukti` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data untuk tabel `sarana_prasarana_penelitian`
--

INSERT INTO `sarana_prasarana_penelitian` (`id`, `nama_prasarana`, `daya_tampung`, `luas_ruang_m2`, `status_kepemilikan`, `status_lisensi`, `perangkat`, `keterangan_lain`, `link_bukti`) VALUES
(1, 'PC Grafis 01', 1, 6.00, 'M', 'L', 'Komputer', 'Animasi', 'http://kampus.ac.id/inventory/pc-g01'),
(2, 'Router Lab A', NULL, 1.00, 'M', 'L', 'Router', 'Praktikum', 'http://kampus.ac.id/inventory/rtr-a'),
(3, 'Proyektor Ruang Rapat', NULL, 1.50, 'W', 'T', 'Proyektor', 'Presentasi', 'http://kampus.ac.id/inventory/proj-01');

-- --------------------------------------------------------

--
-- Struktur dari tabel `sarana_prasarana_pkm`
--

CREATE TABLE `sarana_prasarana_pkm` (
  `No` int(11) DEFAULT NULL,
  `Nama_Prasarana` varchar(255) DEFAULT NULL,
  `Daya_Tampung` int(11) DEFAULT NULL,
  `Luas_Ruang_m2` decimal(10,2) DEFAULT NULL,
  `Kepemilikan` enum('M','S','W') DEFAULT NULL,
  `Lisensi` enum('L','P','T') DEFAULT NULL,
  `Perangkat` text DEFAULT NULL,
  `Keterangan_Lainnya` text DEFAULT NULL,
  `Link_bukti` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data untuk tabel `sarana_prasarana_pkm`
--

INSERT INTO `sarana_prasarana_pkm` (`No`, `Nama_Prasarana`, `Daya_Tampung`, `Luas_Ruang_m2`, `Kepemilikan`, `Lisensi`, `Perangkat`, `Keterangan_Lainnya`, `Link_bukti`) VALUES
(1, 'Contoh nama prasarana 1', 0, 32.00, 'M', 'L', 'contoh perangkat', 'contoh keterangan lainnya', 'http://contoh1.com');

-- --------------------------------------------------------

--
-- Struktur dari tabel `sistemtatakelola`
--

CREATE TABLE `sistemtatakelola` (
  `tatakelolaID` int(11) NOT NULL,
  `JenisTataKelola` varchar(255) DEFAULT NULL,
  `NamaSistem` varchar(255) DEFAULT NULL,
  `Akses` varchar(50) DEFAULT NULL,
  `UnitKerjaSDM` varchar(50) DEFAULT NULL,
  `LinkBukti` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data untuk tabel `sistemtatakelola`
--

INSERT INTO `sistemtatakelola` (`tatakelolaID`, `JenisTataKelola`, `NamaSistem`, `Akses`, `UnitKerjaSDM`, `LinkBukti`) VALUES
(1, 'Manajemen', 'Sistem Keuangan', 'Internal', 'Keuangan', 'https://example.com/keuangan'),
(2, 'Teknologi', 'Sistem Informasi Akademik', 'Publik', 'Akademik', 'https://example.com/akademik'),
(3, 'Operasional', 'Sistem Pengelolaan Inventaris', 'Internal', 'Logistik', 'https://example.com/logistik');

-- --------------------------------------------------------

--
-- Struktur dari tabel `t_6`
--

CREATE TABLE `t_6` (
  `id` int(11) NOT NULL,
  `visi_pt` text DEFAULT NULL,
  `visi_upps` text DEFAULT NULL,
  `visi_keilmuan_ps` text DEFAULT NULL,
  `misi_pt` text DEFAULT NULL,
  `misi_upps` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data untuk tabel `t_6`
--

INSERT INTO `t_6` (`id`, `visi_pt`, `visi_upps`, `visi_keilmuan_ps`, `misi_pt`, `misi_upps`) VALUES
(1, 'Menjadi universitas unggul dan mandiri di Indonesia', 'Melakukan kerjasama dengan berbagai pihak', 'Menyelenggarakan program pendidikan, penelitian dan pengabdian kepada masyarakat', 'Menghasilkan tenaga professional yang memenuhi kebutuhan industri dan masyarakat', 'Pembelajaran selalu mutakhir');

-- --------------------------------------------------------

--
-- Struktur dari tabel `unit_spmi_sdm`
--

CREATE TABLE `unit_spmi_sdm` (
  `unit_spmi` varchar(50) NOT NULL,
  `nama_unit_spmi` varchar(255) DEFAULT NULL,
  `dokumen_spmi` varchar(255) DEFAULT NULL,
  `auditor_certified` int(11) DEFAULT 0,
  `auditor_non_certified` int(11) DEFAULT 0,
  `frekuensi_audit_tahunan` int(11) DEFAULT 0,
  `bukti_certified_auditor` text DEFAULT NULL,
  `laporan_audit` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data untuk tabel `unit_spmi_sdm`
--

INSERT INTO `unit_spmi_sdm` (`unit_spmi`, `nama_unit_spmi`, `dokumen_spmi`, `auditor_certified`, `auditor_non_certified`, `frekuensi_audit_tahunan`, `bukti_certified_auditor`, `laporan_audit`) VALUES
('PT', 'Nama Perguruan Tinggi', 'SK Kebijakan SPMI', 10, 3, 2, 'Dr. Budi, M.Kom., Dr. Ani, M.Si.', 'Laporan AMI 2024'),
('UPPS', 'Nama Unit Pengelola Program Studi', NULL, 0, 0, 0, NULL, NULL);

-- --------------------------------------------------------

--
-- Struktur dari tabel `upload_files`
--

CREATE TABLE `upload_files` (
  `id` int(11) NOT NULL,
  `nama_file` varchar(255) DEFAULT NULL,
  `lokasi_file` varchar(255) DEFAULT NULL,
  `tanggal_upload` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data untuk tabel `upload_files`
--

INSERT INTO `upload_files` (`id`, `nama_file`, `lokasi_file`, `tanggal_upload`) VALUES
(1, 'krok.xlsx', '/uploads/krok.xlsx', '2025-10-28 17:37:38'),
(2, 'kondisi_mahasiswa (dari krok.xlsx)', '/uploads/krok.xlsx', '2025-10-28 18:12:40'),
(3, 'isi_pembelajaran (dari krok.xlsx)', '/uploads/krok.xlsx', '2025-10-28 18:12:40'),
(4, 'pemetaan_cpl (dari krok.xlsx)', '/uploads/krok.xlsx', '2025-10-28 18:12:40'),
(5, 'peta_pemenuhan_cpl (dari krok.xlsx)', '/uploads/krok.xlsx', '2025-10-28 18:12:40');

-- --------------------------------------------------------

--
-- Struktur dari tabel `users`
--

CREATE TABLE `users` (
  `username` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL,
  `name` varchar(100) NOT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

--
-- Dumping data untuk tabel `users`
--

INSERT INTO `users` (`username`, `password`, `name`, `created_at`, `updated_at`) VALUES
('maahaputra', '$2y$10$P8axK9fRPfnlMgZk5VvyJO69R92BxJzmNn1V3j3mAMxuWlCUf6Cgm', 'maha putra', '2025-12-10 03:02:19', '2025-12-10 03:02:19'),
('Maha Putra', '$2y$10$93Z93rN4EvrSctoDh0t0Se7czpKcXB73C7xZd7hpgoPd1jtb8vGT2', 'Maha Putra', '2025-12-02 13:15:48', '2025-12-02 13:15:48');

-- --------------------------------------------------------

--
-- Stand-in struktur untuk tampilan `v_data_mahasiswa_jumlah`
-- (Lihat di bawah untuk tampilan aktual)
--
CREATE TABLE `v_data_mahasiswa_jumlah` (
`ts_tahun` varchar(6)
,`daya_tampung` decimal(32,0)
,`calon_pendaftar_afirmasi` decimal(32,0)
,`calon_pendaftar_khusus` decimal(32,0)
,`calon_pendaftar_kebutuhan` decimal(32,0)
,`maba_reguler_diterima` decimal(32,0)
,`maba_reguler_afirmasi` decimal(32,0)
,`maba_reguler_kebutuhan_khusus` decimal(32,0)
,`maba_rpl_diterima` decimal(32,0)
,`maba_rpl_afirmasi` decimal(32,0)
,`maba_rpl_kebutuhan_khusus` decimal(32,0)
,`aktif_reguler_diterima` decimal(32,0)
,`aktif_reguler_afirmasi` decimal(32,0)
,`aktif_reguler_kebutuhan_khusus` decimal(32,0)
,`aktif_rpl_diterima` decimal(32,0)
,`aktif_rpl_afirmasi` decimal(32,0)
,`aktif_rpl_kebutuhan_khusus` decimal(32,0)
);

-- --------------------------------------------------------

--
-- Stand-in struktur untuk tampilan `v_keragaman_asal_mahasiswa_jumlah`
-- (Lihat di bawah untuk tampilan aktual)
--
CREATE TABLE `v_keragaman_asal_mahasiswa_jumlah` (
`asal_mahasiswa` varchar(100)
,`ts_2` decimal(32,0)
,`ts_1` decimal(32,0)
,`ts` decimal(32,0)
,`link_bukti` varchar(255)
);

-- --------------------------------------------------------

--
-- Stand-in struktur untuk tampilan `v_kualifikasi_total`
-- (Lihat di bawah untuk tampilan aktual)
--
CREATE TABLE `v_kualifikasi_total` (
`no` int(11)
,`jenis_tenaga` varchar(100)
,`s3` decimal(32,0)
,`s2` decimal(32,0)
,`s1` decimal(32,0)
,`d4` decimal(32,0)
,`d3` decimal(32,0)
,`d2` decimal(32,0)
,`d1` decimal(32,0)
,`sma_smk` decimal(32,0)
,`unit_kerja` varchar(100)
);

-- --------------------------------------------------------

--
-- Stand-in struktur untuk tampilan `v_rekap_penelitian_dtpr`
-- (Lihat di bawah untuk tampilan aktual)
--
CREATE TABLE `v_rekap_penelitian_dtpr` (
`Nama DTPR (Ketua)` varchar(255)
,`Judul Penelitian` mediumtext
,`Jumlah Mahasiswa yang Terlibat` bigint(21)
,`Jenis Hibah Penelitian` varchar(100)
,`Sumber` enum('L','N','I')
,`Durasi` varchar(50)
,`Pendanaan (Rp Juta) TS-2` decimal(37,2)
,`Pendanaan (Rp Juta) TS-1` decimal(37,2)
,`Pendanaan (Rp Juta) TS` decimal(37,2)
,`Link Bukti` varchar(255)
);

-- --------------------------------------------------------

--
-- Stand-in struktur untuk tampilan `v_rekap_pengembangan_dtpr`
-- (Lihat di bawah untuk tampilan aktual)
--
CREATE TABLE `v_rekap_pengembangan_dtpr` (
`Jenis Pengembangan DTPR` varchar(255)
,`Nama DTPR` varchar(255)
,`Jumlah (TS-2)` decimal(32,0)
,`Jumlah (TS-1)` decimal(32,0)
,`Jumlah (TS)` decimal(32,0)
,`Link Bukti` varchar(255)
);

-- --------------------------------------------------------

--
-- Stand-in struktur untuk tampilan `v_rekap_rekognisi`
-- (Lihat di bawah untuk tampilan aktual)
--
CREATE TABLE `v_rekap_rekognisi` (
`Sumber Rekognisi` varchar(100)
,`Jenis Pengakuan Lulusan (Rekognisi)` varchar(255)
,`TS-2` decimal(39,4)
,`TS-1` decimal(39,4)
,`TS` decimal(39,4)
,`Link Bukti` varchar(255)
);

-- --------------------------------------------------------

--
-- Stand-in struktur untuk tampilan `v_unit_spmi_sdm`
-- (Lihat di bawah untuk tampilan aktual)
--
CREATE TABLE `v_unit_spmi_sdm` (
`unit_spmi` varchar(50)
,`nama_unit_spmi` varchar(255)
,`dokumen_spmi` varchar(255)
,`jumlah_auditor_mutu` bigint(12)
,`auditor_certified` int(11)
,`auditor_non_certified` int(11)
,`frekuensi_audit_tahunan` int(11)
,`bukti_certified_auditor` text
,`laporan_audit` varchar(255)
);

-- --------------------------------------------------------

--
-- Struktur dari tabel `within`
--

CREATE TABLE `within` (
  `director` int(5) UNSIGNED NOT NULL,
  `shoulder` varchar(15) DEFAULT NULL,
  `successful` varchar(15) DEFAULT NULL,
  `use` varchar(15) DEFAULT NULL,
  `participant` varchar(10) DEFAULT NULL,
  `strong` varchar(5) DEFAULT NULL,
  `protect` varchar(15) DEFAULT NULL,
  `cause` varchar(20) DEFAULT NULL,
  `record` varchar(10) DEFAULT NULL,
  `policy` varchar(5) DEFAULT NULL,
  `center` varchar(5) DEFAULT NULL,
  `created_at` datetime DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

-- --------------------------------------------------------

--
-- Struktur untuk view `v_data_mahasiswa_jumlah`
--
DROP TABLE IF EXISTS `v_data_mahasiswa_jumlah`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `v_data_mahasiswa_jumlah`  AS SELECT `data_mahasiswa`.`ts_tahun` AS `ts_tahun`, `data_mahasiswa`.`daya_tampung` AS `daya_tampung`, `data_mahasiswa`.`calon_pendaftar_afirmasi` AS `calon_pendaftar_afirmasi`, `data_mahasiswa`.`calon_pendaftar_khusus` AS `calon_pendaftar_khusus`, `data_mahasiswa`.`calon_pendaftar_kebutuhan` AS `calon_pendaftar_kebutuhan`, `data_mahasiswa`.`maba_reguler_diterima` AS `maba_reguler_diterima`, `data_mahasiswa`.`maba_reguler_afirmasi` AS `maba_reguler_afirmasi`, `data_mahasiswa`.`maba_reguler_kebutuhan_khusus` AS `maba_reguler_kebutuhan_khusus`, `data_mahasiswa`.`maba_rpl_diterima` AS `maba_rpl_diterima`, `data_mahasiswa`.`maba_rpl_afirmasi` AS `maba_rpl_afirmasi`, `data_mahasiswa`.`maba_rpl_kebutuhan_khusus` AS `maba_rpl_kebutuhan_khusus`, `data_mahasiswa`.`aktif_reguler_diterima` AS `aktif_reguler_diterima`, `data_mahasiswa`.`aktif_reguler_afirmasi` AS `aktif_reguler_afirmasi`, `data_mahasiswa`.`aktif_reguler_kebutuhan_khusus` AS `aktif_reguler_kebutuhan_khusus`, `data_mahasiswa`.`aktif_rpl_diterima` AS `aktif_rpl_diterima`, `data_mahasiswa`.`aktif_rpl_afirmasi` AS `aktif_rpl_afirmasi`, `data_mahasiswa`.`aktif_rpl_kebutuhan_khusus` AS `aktif_rpl_kebutuhan_khusus` FROM `data_mahasiswa`union all select 'Jumlah' AS `ts_tahun`,sum(`data_mahasiswa`.`daya_tampung`) AS `daya_tampung`,sum(`data_mahasiswa`.`calon_pendaftar_afirmasi`) AS `calon_pendaftar_afirmasi`,sum(`data_mahasiswa`.`calon_pendaftar_khusus`) AS `calon_pendaftar_khusus`,sum(`data_mahasiswa`.`calon_pendaftar_kebutuhan`) AS `calon_pendaftar_kebutuhan`,sum(`data_mahasiswa`.`maba_reguler_diterima`) AS `maba_reguler_diterima`,sum(`data_mahasiswa`.`maba_reguler_afirmasi`) AS `maba_reguler_afirmasi`,sum(`data_mahasiswa`.`maba_reguler_kebutuhan_khusus`) AS `maba_reguler_kebutuhan_khusus`,sum(`data_mahasiswa`.`maba_rpl_diterima`) AS `maba_rpl_diterima`,sum(`data_mahasiswa`.`maba_rpl_afirmasi`) AS `maba_rpl_afirmasi`,sum(`data_mahasiswa`.`maba_rpl_kebutuhan_khusus`) AS `maba_rpl_kebutuhan_khusus`,sum(`data_mahasiswa`.`aktif_reguler_diterima`) AS `aktif_reguler_diterima`,sum(`data_mahasiswa`.`aktif_reguler_afirmasi`) AS `aktif_reguler_afirmasi`,sum(`data_mahasiswa`.`aktif_reguler_kebutuhan_khusus`) AS `aktif_reguler_kebutuhan_khusus`,sum(`data_mahasiswa`.`aktif_rpl_diterima`) AS `aktif_rpl_diterima`,sum(`data_mahasiswa`.`aktif_rpl_afirmasi`) AS `aktif_rpl_afirmasi`,sum(`data_mahasiswa`.`aktif_rpl_kebutuhan_khusus`) AS `aktif_rpl_kebutuhan_khusus` from `data_mahasiswa`  ;

-- --------------------------------------------------------

--
-- Struktur untuk view `v_keragaman_asal_mahasiswa_jumlah`
--
DROP TABLE IF EXISTS `v_keragaman_asal_mahasiswa_jumlah`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `v_keragaman_asal_mahasiswa_jumlah`  AS SELECT `keragaman_asal_mahasiswa`.`asal_mahasiswa` AS `asal_mahasiswa`, `keragaman_asal_mahasiswa`.`ts_2` AS `ts_2`, `keragaman_asal_mahasiswa`.`ts_1` AS `ts_1`, `keragaman_asal_mahasiswa`.`ts` AS `ts`, `keragaman_asal_mahasiswa`.`link_bukti` AS `link_bukti` FROM `keragaman_asal_mahasiswa`union all select 'Jumlah' AS `asal_mahasiswa`,sum(`keragaman_asal_mahasiswa`.`ts_2`) AS `ts_2`,sum(`keragaman_asal_mahasiswa`.`ts_1`) AS `ts_1`,sum(`keragaman_asal_mahasiswa`.`ts`) AS `ts`,NULL AS `link_bukti` from `keragaman_asal_mahasiswa`  ;

-- --------------------------------------------------------

--
-- Struktur untuk view `v_kualifikasi_total`
--
DROP TABLE IF EXISTS `v_kualifikasi_total`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `v_kualifikasi_total`  AS SELECT `kualifikasi_tenaga_kependidikan`.`no` AS `no`, `kualifikasi_tenaga_kependidikan`.`jenis_tenaga` AS `jenis_tenaga`, `kualifikasi_tenaga_kependidikan`.`s3` AS `s3`, `kualifikasi_tenaga_kependidikan`.`s2` AS `s2`, `kualifikasi_tenaga_kependidikan`.`s1` AS `s1`, `kualifikasi_tenaga_kependidikan`.`d4` AS `d4`, `kualifikasi_tenaga_kependidikan`.`d3` AS `d3`, `kualifikasi_tenaga_kependidikan`.`d2` AS `d2`, `kualifikasi_tenaga_kependidikan`.`d1` AS `d1`, `kualifikasi_tenaga_kependidikan`.`sma_smk` AS `sma_smk`, `kualifikasi_tenaga_kependidikan`.`unit_kerja` AS `unit_kerja` FROM `kualifikasi_tenaga_kependidikan`union all select NULL AS `no`,'Total' AS `jenis_tenaga`,sum(`kualifikasi_tenaga_kependidikan`.`s3`) AS `s3`,sum(`kualifikasi_tenaga_kependidikan`.`s2`) AS `s2`,sum(`kualifikasi_tenaga_kependidikan`.`s1`) AS `s1`,sum(`kualifikasi_tenaga_kependidikan`.`d4`) AS `d4`,sum(`kualifikasi_tenaga_kependidikan`.`d3`) AS `d3`,sum(`kualifikasi_tenaga_kependidikan`.`d2`) AS `d2`,sum(`kualifikasi_tenaga_kependidikan`.`d1`) AS `d1`,sum(`kualifikasi_tenaga_kependidikan`.`sma_smk`) AS `sma_smk`,NULL AS `unit_kerja` from `kualifikasi_tenaga_kependidikan`  ;

-- --------------------------------------------------------

--
-- Struktur untuk view `v_rekap_penelitian_dtpr`
--
DROP TABLE IF EXISTS `v_rekap_penelitian_dtpr`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `v_rekap_penelitian_dtpr`  AS SELECT `kueriinternal`.`Nama DTPR (Ketua)` AS `Nama DTPR (Ketua)`, `kueriinternal`.`Judul Penelitian` AS `Judul Penelitian`, `kueriinternal`.`Jumlah Mahasiswa yang Terlibat` AS `Jumlah Mahasiswa yang Terlibat`, `kueriinternal`.`Jenis Hibah Penelitian` AS `Jenis Hibah Penelitian`, `kueriinternal`.`Sumber` AS `Sumber`, `kueriinternal`.`Durasi` AS `Durasi`, `kueriinternal`.`Pendanaan (Rp Juta) TS-2` AS `Pendanaan (Rp Juta) TS-2`, `kueriinternal`.`Pendanaan (Rp Juta) TS-1` AS `Pendanaan (Rp Juta) TS-1`, `kueriinternal`.`Pendanaan (Rp Juta) TS` AS `Pendanaan (Rp Juta) TS`, `kueriinternal`.`Link Bukti` AS `Link Bukti` FROM (with Summary as (select count(`penelitian_dtpr`.`id`) AS `total_penelitian`,count(distinct `penelitian_dtpr`.`jenis_hibah_penelitian`) AS `total_jenis_hibah`,sum(`penelitian_dtpr`.`pendanaan_ts_2`) AS `total_dana_ts_2`,sum(`penelitian_dtpr`.`pendanaan_ts_1`) AS `total_dana_ts_1`,sum(`penelitian_dtpr`.`pendanaan_ts`) AS `total_dana_ts` from `penelitian_dtpr`)select 1 AS `urutan_grup`,`penelitian_dtpr`.`id` AS `urutan_baris`,`penelitian_dtpr`.`nama_dtpr` AS `Nama DTPR (Ketua)`,`penelitian_dtpr`.`judul_penelitian` AS `Judul Penelitian`,`penelitian_dtpr`.`jml_mahasiswa_terlibat` AS `Jumlah Mahasiswa yang Terlibat`,`penelitian_dtpr`.`jenis_hibah_penelitian` AS `Jenis Hibah Penelitian`,`penelitian_dtpr`.`sumber` AS `Sumber`,`penelitian_dtpr`.`durasi` AS `Durasi`,`penelitian_dtpr`.`pendanaan_ts_2` AS `Pendanaan (Rp Juta) TS-2`,`penelitian_dtpr`.`pendanaan_ts_1` AS `Pendanaan (Rp Juta) TS-1`,`penelitian_dtpr`.`pendanaan_ts` AS `Pendanaan (Rp Juta) TS`,`penelitian_dtpr`.`link_bukti` AS `Link Bukti` from `penelitian_dtpr` union all select 2 AS `urutan_grup`,1 AS `urutan_baris`,'Jumlah Penelitian' AS `Nama DTPR (Ketua)`,NULL AS `NULL`,`summary`.`total_penelitian` AS `total_penelitian`,NULL AS `NULL`,NULL AS `NULL`,NULL AS `NULL`,NULL AS `NULL`,NULL AS `NULL`,NULL AS `NULL`,NULL AS `NULL` from `summary` union all select 2 AS `urutan_grup`,2 AS `urutan_baris`,'Jumlah Jenis Hibah' AS `Nama DTPR (Ketua)`,NULL AS `NULL`,NULL AS `NULL`,`summary`.`total_jenis_hibah` AS `total_jenis_hibah`,NULL AS `NULL`,NULL AS `NULL`,NULL AS `NULL`,NULL AS `NULL`,NULL AS `NULL`,NULL AS `NULL` from `summary` union all select 2 AS `urutan_grup`,3 AS `urutan_baris`,'Jumlah Dana' AS `Nama DTPR (Ketua)`,NULL AS `NULL`,NULL AS `NULL`,NULL AS `NULL`,NULL AS `NULL`,NULL AS `NULL`,`summary`.`total_dana_ts_2` AS `total_dana_ts_2`,`summary`.`total_dana_ts_1` AS `total_dana_ts_1`,`summary`.`total_dana_ts` AS `total_dana_ts`,NULL AS `NULL` from `summary` order by `urutan_grup`,`urutan_baris`) AS `kueriinternal` ;

-- --------------------------------------------------------

--
-- Struktur untuk view `v_rekap_pengembangan_dtpr`
--
DROP TABLE IF EXISTS `v_rekap_pengembangan_dtpr`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `v_rekap_pengembangan_dtpr`  AS SELECT `kueriinternal`.`Jenis Pengembangan DTPR` AS `Jenis Pengembangan DTPR`, `kueriinternal`.`Nama DTPR` AS `Nama DTPR`, `kueriinternal`.`Jumlah (TS-2)` AS `Jumlah (TS-2)`, `kueriinternal`.`Jumlah (TS-1)` AS `Jumlah (TS-1)`, `kueriinternal`.`Jumlah (TS)` AS `Jumlah (TS)`, `kueriinternal`.`Link Bukti` AS `Link Bukti` FROM (with Summary as (select sum(`pengembangan_dtpr`.`jumlah_ts_2`) AS `total_ts_2`,sum(`pengembangan_dtpr`.`jumlah_ts_1`) AS `total_ts_1`,sum(`pengembangan_dtpr`.`jumlah_ts`) AS `total_ts` from `pengembangan_dtpr`)select 1 AS `urutan_grup`,`pengembangan_dtpr`.`id` AS `urutan_baris`,`pengembangan_dtpr`.`jenis_pengembangan_dtpr` AS `Jenis Pengembangan DTPR`,`pengembangan_dtpr`.`nama_dtpr` AS `Nama DTPR`,`pengembangan_dtpr`.`jumlah_ts_2` AS `Jumlah (TS-2)`,`pengembangan_dtpr`.`jumlah_ts_1` AS `Jumlah (TS-1)`,`pengembangan_dtpr`.`jumlah_ts` AS `Jumlah (TS)`,`pengembangan_dtpr`.`link_bukti` AS `Link Bukti` from `pengembangan_dtpr` union all select 2 AS `urutan_grup`,1 AS `urutan_baris`,'Jumlah Dosen DTPR' AS `Jenis Pengembangan DTPR`,NULL AS `Nama DTPR`,`summary`.`total_ts_2` AS `Jumlah (TS-2)`,`summary`.`total_ts_1` AS `Jumlah (TS-1)`,`summary`.`total_ts` AS `Jumlah (TS)`,NULL AS `Link Bukti` from `summary` order by `urutan_grup`,`urutan_baris`) AS `kueriinternal` ;

-- --------------------------------------------------------

--
-- Struktur untuk view `v_rekap_rekognisi`
--
DROP TABLE IF EXISTS `v_rekap_rekognisi`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `v_rekap_rekognisi`  AS SELECT `kueriinternal`.`Sumber Rekognisi` AS `Sumber Rekognisi`, `kueriinternal`.`Jenis Pengakuan Lulusan (Rekognisi)` AS `Jenis Pengakuan Lulusan (Rekognisi)`, `kueriinternal`.`TS-2` AS `TS-2`, `kueriinternal`.`TS-1` AS `TS-1`, `kueriinternal`.`TS` AS `TS`, `kueriinternal`.`Link Bukti` AS `Link Bukti` FROM (with TotalRekognisi as (select sum(`rekognisi_lulusan`.`ts_2`) AS `Jml_Rekognisi_TS2`,sum(`rekognisi_lulusan`.`ts_1`) AS `Jml_Rekognisi_TS1`,sum(`rekognisi_lulusan`.`ts`) AS `Jml_Rekognisi_TS` from `rekognisi_lulusan` where `rekognisi_lulusan`.`kategori` = 'Rekognisi'), TotalLulusan as (select `rekognisi_lulusan`.`ts_2` AS `Jml_Lulusan_TS2`,`rekognisi_lulusan`.`ts_1` AS `Jml_Lulusan_TS1`,`rekognisi_lulusan`.`ts` AS `Jml_Lulusan_TS` from `rekognisi_lulusan` where `rekognisi_lulusan`.`kategori` = 'Lulusan' limit 1)select 1 AS `urutan_grup`,`rekognisi_lulusan`.`id` AS `urutan_baris`,`rekognisi_lulusan`.`sumber` AS `Sumber Rekognisi`,`rekognisi_lulusan`.`jenis_pengakuan` AS `Jenis Pengakuan Lulusan (Rekognisi)`,`rekognisi_lulusan`.`ts_2` AS `TS-2`,`rekognisi_lulusan`.`ts_1` AS `TS-1`,`rekognisi_lulusan`.`ts` AS `TS`,`rekognisi_lulusan`.`link_bukti` AS `Link Bukti` from `rekognisi_lulusan` where `rekognisi_lulusan`.`kategori` = 'Rekognisi' union all select 2 AS `urutan_grup`,1 AS `urutan_baris`,'Jumlah Rekognisi' AS `Sumber Rekognisi`,NULL AS `Jenis Pengakuan Lulusan (Rekognisi)`,`totalrekognisi`.`Jml_Rekognisi_TS2` AS `Jml_Rekognisi_TS2`,`totalrekognisi`.`Jml_Rekognisi_TS1` AS `Jml_Rekognisi_TS1`,`totalrekognisi`.`Jml_Rekognisi_TS` AS `Jml_Rekognisi_TS`,NULL AS `Link Bukti` from `totalrekognisi` union all select 2 AS `urutan_grup`,2 AS `urutan_baris`,`rekognisi_lulusan`.`sumber` AS `Sumber Rekognisi`,NULL AS `Jenis Pengakuan Lulusan (Rekognisi)`,`rekognisi_lulusan`.`ts_2` AS `ts_2`,`rekognisi_lulusan`.`ts_1` AS `ts_1`,`rekognisi_lulusan`.`ts` AS `ts`,NULL AS `Link Bukti` from `rekognisi_lulusan` where `rekognisi_lulusan`.`kategori` = 'Lulusan' union all select 2 AS `urutan_grup`,3 AS `urutan_baris`,'Persentase' AS `Sumber Rekognisi`,NULL AS `Jenis Pengakuan Lulusan (Rekognisi)`,ifnull(`totalrekognisi`.`Jml_Rekognisi_TS2` / nullif(`totallulusan`.`Jml_Lulusan_TS2`,0) * 100,0) AS `TS-2`,ifnull(`totalrekognisi`.`Jml_Rekognisi_TS1` / nullif(`totallulusan`.`Jml_Lulusan_TS1`,0) * 100,0) AS `TS-1`,ifnull(`totalrekognisi`.`Jml_Rekognisi_TS` / nullif(`totallulusan`.`Jml_Lulusan_TS`,0) * 100,0) AS `TS`,NULL AS `Link Bukti` from (`totalrekognisi` join `totallulusan`) order by `urutan_grup`,`urutan_baris`) AS `kueriinternal` ;

-- --------------------------------------------------------

--
-- Struktur untuk view `v_unit_spmi_sdm`
--
DROP TABLE IF EXISTS `v_unit_spmi_sdm`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `v_unit_spmi_sdm`  AS SELECT `unit_spmi_sdm`.`unit_spmi` AS `unit_spmi`, `unit_spmi_sdm`.`nama_unit_spmi` AS `nama_unit_spmi`, `unit_spmi_sdm`.`dokumen_spmi` AS `dokumen_spmi`, `unit_spmi_sdm`.`auditor_certified`+ `unit_spmi_sdm`.`auditor_non_certified` AS `jumlah_auditor_mutu`, `unit_spmi_sdm`.`auditor_certified` AS `auditor_certified`, `unit_spmi_sdm`.`auditor_non_certified` AS `auditor_non_certified`, `unit_spmi_sdm`.`frekuensi_audit_tahunan` AS `frekuensi_audit_tahunan`, `unit_spmi_sdm`.`bukti_certified_auditor` AS `bukti_certified_auditor`, `unit_spmi_sdm`.`laporan_audit` AS `laporan_audit` FROM `unit_spmi_sdm` ;

--
-- Indexes for dumped tables
--

--
-- Indeks untuk tabel `1a1`
--
ALTER TABLE `1a1`
  ADD PRIMARY KEY (`id`);

--
-- Indeks untuk tabel `1a2`
--
ALTER TABLE `1a2`
  ADD PRIMARY KEY (`id`);

--
-- Indeks untuk tabel `1a3`
--
ALTER TABLE `1a3`
  ADD PRIMARY KEY (`id`);

--
-- Indeks untuk tabel `1a4`
--
ALTER TABLE `1a4`
  ADD PRIMARY KEY (`id`);

--
-- Indeks untuk tabel `1a5`
--
ALTER TABLE `1a5`
  ADD PRIMARY KEY (`id`);

--
-- Indeks untuk tabel `4c3`
--
ALTER TABLE `4c3`
  ADD PRIMARY KEY (`no`);

--
-- Indeks untuk tabel `5_1`
--
ALTER TABLE `5_1`
  ADD PRIMARY KEY (`no`);

--
-- Indeks untuk tabel `5_2`
--
ALTER TABLE `5_2`
  ADD PRIMARY KEY (`id`);

--
-- Indeks untuk tabel `data_mahasiswa`
--
ALTER TABLE `data_mahasiswa`
  ADD PRIMARY KEY (`ts_tahun`);

--
-- Indeks untuk tabel `isi_pembelajaran`
--
ALTER TABLE `isi_pembelajaran`
  ADD PRIMARY KEY (`no`);

--
-- Indeks untuk tabel `kepuasan_pengguna_lulusan`
--
ALTER TABLE `kepuasan_pengguna_lulusan`
  ADD PRIMARY KEY (`id`);

--
-- Indeks untuk tabel `keragaman_asal_mahasiswa`
--
ALTER TABLE `keragaman_asal_mahasiswa`
  ADD PRIMARY KEY (`asal_mahasiswa`);

--
-- Indeks untuk tabel `kesesuaianvisimisi`
--
ALTER TABLE `kesesuaianvisimisi`
  ADD PRIMARY KEY (`VismisID`);

--
-- Indeks untuk tabel `kesesuaian_bidang_kerja_lulusan`
--
ALTER TABLE `kesesuaian_bidang_kerja_lulusan`
  ADD PRIMARY KEY (`id`);

--
-- Indeks untuk tabel `kondisi_mahasiswa`
--
ALTER TABLE `kondisi_mahasiswa`
  ADD PRIMARY KEY (`id`),
  ADD KEY `upload_id` (`upload_id`);

--
-- Indeks untuk tabel `kond_jumlah_mahasiswa`
--
ALTER TABLE `kond_jumlah_mahasiswa`
  ADD PRIMARY KEY (`id`);

--
-- Indeks untuk tabel `kualifikasi_tenaga_kependidikan`
--
ALTER TABLE `kualifikasi_tenaga_kependidikan`
  ADD PRIMARY KEY (`no`);

--
-- Indeks untuk tabel `migrations`
--
ALTER TABLE `migrations`
  ADD PRIMARY KEY (`id`);

--
-- Indeks untuk tabel `pemetaan_cpl`
--
ALTER TABLE `pemetaan_cpl`
  ADD PRIMARY KEY (`id`);

--
-- Indeks untuk tabel `penelitian_dtpr`
--
ALTER TABLE `penelitian_dtpr`
  ADD PRIMARY KEY (`id`);

--
-- Indeks untuk tabel `pengembangan_dtpr`
--
ALTER TABLE `pengembangan_dtpr`
  ADD PRIMARY KEY (`id`);

--
-- Indeks untuk tabel `perolehanhkipkm`
--
ALTER TABLE `perolehanhkipkm`
  ADD PRIMARY KEY (`hkiID`);

--
-- Indeks untuk tabel `peta_pemenuhan_cpl`
--
ALTER TABLE `peta_pemenuhan_cpl`
  ADD PRIMARY KEY (`id`);

--
-- Indeks untuk tabel `rata_rata_masa_tunggu`
--
ALTER TABLE `rata_rata_masa_tunggu`
  ADD PRIMARY KEY (`id`);

--
-- Indeks untuk tabel `rekognisi_lulusan`
--
ALTER TABLE `rekognisi_lulusan`
  ADD PRIMARY KEY (`id`);

--
-- Indeks untuk tabel `saranadanprasaranapendidikan`
--
ALTER TABLE `saranadanprasaranapendidikan`
  ADD PRIMARY KEY (`prasaranaID`);

--
-- Indeks untuk tabel `sarana_prasarana_penelitian`
--
ALTER TABLE `sarana_prasarana_penelitian`
  ADD PRIMARY KEY (`id`);

--
-- Indeks untuk tabel `sistemtatakelola`
--
ALTER TABLE `sistemtatakelola`
  ADD PRIMARY KEY (`tatakelolaID`);

--
-- Indeks untuk tabel `t_6`
--
ALTER TABLE `t_6`
  ADD PRIMARY KEY (`id`);

--
-- Indeks untuk tabel `unit_spmi_sdm`
--
ALTER TABLE `unit_spmi_sdm`
  ADD PRIMARY KEY (`unit_spmi`);

--
-- Indeks untuk tabel `upload_files`
--
ALTER TABLE `upload_files`
  ADD PRIMARY KEY (`id`);

--
-- Indeks untuk tabel `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`username`);

--
-- Indeks untuk tabel `within`
--
ALTER TABLE `within`
  ADD PRIMARY KEY (`director`);

--
-- AUTO_INCREMENT untuk tabel yang dibuang
--

--
-- AUTO_INCREMENT untuk tabel `1a1`
--
ALTER TABLE `1a1`
  MODIFY `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT untuk tabel `1a2`
--
ALTER TABLE `1a2`
  MODIFY `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT untuk tabel `1a3`
--
ALTER TABLE `1a3`
  MODIFY `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT untuk tabel `1a4`
--
ALTER TABLE `1a4`
  MODIFY `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT untuk tabel `1a5`
--
ALTER TABLE `1a5`
  MODIFY `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT untuk tabel `4c3`
--
ALTER TABLE `4c3`
  MODIFY `no` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT untuk tabel `5_1`
--
ALTER TABLE `5_1`
  MODIFY `no` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT untuk tabel `5_2`
--
ALTER TABLE `5_2`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT untuk tabel `isi_pembelajaran`
--
ALTER TABLE `isi_pembelajaran`
  MODIFY `no` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT untuk tabel `kepuasan_pengguna_lulusan`
--
ALTER TABLE `kepuasan_pengguna_lulusan`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT untuk tabel `kesesuaianvisimisi`
--
ALTER TABLE `kesesuaianvisimisi`
  MODIFY `VismisID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT untuk tabel `kesesuaian_bidang_kerja_lulusan`
--
ALTER TABLE `kesesuaian_bidang_kerja_lulusan`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT untuk tabel `kondisi_mahasiswa`
--
ALTER TABLE `kondisi_mahasiswa`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT untuk tabel `kond_jumlah_mahasiswa`
--
ALTER TABLE `kond_jumlah_mahasiswa`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT untuk tabel `kualifikasi_tenaga_kependidikan`
--
ALTER TABLE `kualifikasi_tenaga_kependidikan`
  MODIFY `no` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT untuk tabel `migrations`
--
ALTER TABLE `migrations`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT untuk tabel `pemetaan_cpl`
--
ALTER TABLE `pemetaan_cpl`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT untuk tabel `penelitian_dtpr`
--
ALTER TABLE `penelitian_dtpr`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT untuk tabel `pengembangan_dtpr`
--
ALTER TABLE `pengembangan_dtpr`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT untuk tabel `perolehanhkipkm`
--
ALTER TABLE `perolehanhkipkm`
  MODIFY `hkiID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT untuk tabel `peta_pemenuhan_cpl`
--
ALTER TABLE `peta_pemenuhan_cpl`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT untuk tabel `rata_rata_masa_tunggu`
--
ALTER TABLE `rata_rata_masa_tunggu`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT untuk tabel `rekognisi_lulusan`
--
ALTER TABLE `rekognisi_lulusan`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT untuk tabel `saranadanprasaranapendidikan`
--
ALTER TABLE `saranadanprasaranapendidikan`
  MODIFY `prasaranaID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT untuk tabel `sarana_prasarana_penelitian`
--
ALTER TABLE `sarana_prasarana_penelitian`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT untuk tabel `sistemtatakelola`
--
ALTER TABLE `sistemtatakelola`
  MODIFY `tatakelolaID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT untuk tabel `t_6`
--
ALTER TABLE `t_6`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT untuk tabel `upload_files`
--
ALTER TABLE `upload_files`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT untuk tabel `within`
--
ALTER TABLE `within`
  MODIFY `director` int(5) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- Ketidakleluasaan untuk tabel pelimpahan (Dumped Tables)
--

--
-- Ketidakleluasaan untuk tabel `kondisi_mahasiswa`
--
ALTER TABLE `kondisi_mahasiswa`
  ADD CONSTRAINT `kondisi_mahasiswa_ibfk_1` FOREIGN KEY (`upload_id`) REFERENCES `upload_files` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
